SELECT * FROM view_pol_elect_soat WHERE txt_patente = 'FQS313'
SELECT * FROM view_pol_elect_soat WHERE txt_patente = 'FRX738' OR txt_patente = 'CCW256'

--ViewResult Request ExpedirPolizaXML - Jmeter
	44	&lt;cod_clase_soat&gt;${codClaseSoat}&lt;/cod_clase_soat&gt;
	46	&lt;nro_formulario&gt;${numFormulario}&lt;/nro_formulario&gt;
	61	&lt;txt_vin&gt;${txtVin};/txt_vin&gt;
	62	&lt;cotizador&gt;&lt;/cotizador&gt;