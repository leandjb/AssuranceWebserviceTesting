--Consulta estado poliza por Placa 
SELECT * FROM view_pol_elect_soat WHERE txt_patente = 'JCF44D'